#include <stdio.h>

int StringLength(char sentence[]);
int NumOfWords(char sentence[], int StrLength);
int NumOfVowels(char sentence[], int StrLength);
void VowelFreq (char sentence[]);

int main() {
    char chArr[100];
	printf("\nEnter the Sentence: ");
	scanf("%[^\n]%*c",chArr);
	
	printf("\nLength = %d",StringLength(chArr));
	printf("\nNumber of Words = %d",NumOfWords(chArr,StringLength(chArr)));
	printf("\nNumber of Vowels = %d",NumOfVowels(chArr, StringLength(chArr)));
	printf("\nFreq of Vowels:\n");
	VowelFreq (chArr);	

    return 0;
}

int StringLength(char sentence[]){
	int Counter = 0;
	for(int i = 0; i <= 100; i++) {
		Counter++;
		if(sentence[i] == '\0')
			break;
	}
	return Counter - 1;
}

int NumOfWords(char sentence[], int StrLength){
	int Counter = 0;
	for(int i = 0; i <= StrLength; i++) {
		if(sentence[i] == ' ')
			Counter++;
	}
	Counter++;
	return Counter;
}

int NumOfVowels(char sentence[], int StrLength){
	int Counter = 0;
	for(int i = 0; i <= StrLength; i++) {
		if(sentence[i] == 'a' || sentence[i] == 'A' || sentence[i] == 'e'|| sentence[i] == 'E' || sentence[i] == 'o' || sentence[i] == 'O' || sentence[i] == 'i' || sentence[i] == 'I' || sentence[i] == 'U' || sentence[i] == 'u')
			Counter++;
	}
	return Counter;
}

void VowelFreq (char sentence[]){
	int CounterA = 0, CounterE = 0, CounterO = 0, CounterI = 0, CounterU = 0;
		for(int i = 0; i <= 100; i++) {
			if(sentence[i] == '\0')
				break;
			if(sentence[i] == sentence[i] == 'a' || sentence[i] == 'A')
			CounterA++;
			
			else if(sentence[i] == 'e'|| sentence[i] == 'E')
			CounterE++;
			
			else if(sentence[i] == 'o' || sentence[i] == 'O')
			CounterO++;
			
			else if(sentence[i] == 'i' || sentence[i] == 'I')
			CounterI++;
			
			else if(sentence[i] == 'u' || sentence    [i] == 'U')
			CounterU++;
			
		}
		printf("\n\nFreq of A = %d",CounterA);
		printf("\nFreq of E = %d",CounterE);
		printf("\nFreq of I = %d",CounterI);
		printf("\nFreq of O = %d",CounterO);
		printf("\nFreq of U = %d\n",CounterU);
}
