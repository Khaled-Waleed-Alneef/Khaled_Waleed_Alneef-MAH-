#include <stdio.h>

int main(){

int intN = 1;
char *chP = (char*) &intN;

	if(*chP == 1)
		printf("Little Endian\n");
	else
		printf("Big Endian\n");
	
	if(sizeof(int*) == 8)
		printf("64 Bit\n");
	else 
		printf("32 Bit\n");

  return 0;
}
