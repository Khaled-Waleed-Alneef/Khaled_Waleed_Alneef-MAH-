#include <stdio.h>

int intAdd(int a, int b);
float fAdd(float a, float b);
float fAOC(float r);
float fAOR(float a, float b);
int intF(int n);

int main() {
    	printf("4 + 4 = %d\n",intAdd(4,4));
	printf("2.5 + 2.5 = %f\n",fAdd(2.5,2.5));
	printf("Area of Circle with r = 5 is: %f\n",fAOC(5));
	printf("Area of 6 X 6.5 Rectangle = %f\n",fAOR(6,6.5));
	printf("5! = %d\n",intF(5));	
    return 0;
}

int intAdd(int a, int b){
	return a + b;
}

float fAdd(float a, float b){
	return a + b;
}

float fAOC(float r){
	return r * r * 3.1415926;
}

float fAOR(float a, float b){
	return a * b;
}
int intF(int n){
	int Result = 1;
	for(int i = n; i > 0; i--){
		Result *= i;
	}
	return Result;
}
