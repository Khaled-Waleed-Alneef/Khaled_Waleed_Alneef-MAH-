#include <stdio.h>

int main(){

int intArr[4];
char chArr[4];
short shArr[4];
double dArr[4];
	
	printf("Integer Array: \n");

	for(int i = 0; i < 4; i++) {
	
		printf("%p\n",&intArr[i]);
	}
	
	printf("\nCharacter Array: \n");

	for(int i = 0; i < 4; i++) {
                
                printf("%p\n",&chArr[i]);
        }
	
	printf("\nShort Array: \n");
      
        for(int i = 0; i < 4; i++) {

                printf("%p\n",&shArr[i]);
        }

	printf("\nDouble Array: \n");
        
        for(int i = 0; i < 4; i++) {
                
                printf("%p\n",&dArr[i]);
        }
	
  return 0;
}
