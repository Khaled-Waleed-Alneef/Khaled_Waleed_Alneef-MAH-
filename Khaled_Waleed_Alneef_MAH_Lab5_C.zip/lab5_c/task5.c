#include <stdio.h>

void MatrixVectorOp(int Col,int Arr1[][Col], int Arr2[],int Row);

int main() {
int intR, intC, intN;	

	printf("\nEnter Size of Matrix A [Row , Columns] : ");
	scanf("%d%d",&intR,&intC);

	int A[intR][intC];
	int X[intR];
	
	for(int i = 0; i < intR; i++) {
		for(int j = 0; j < intC; j++){
			printf("\nEnter Value Number [%d ,%d] in Matrix A: ",i,j);
			scanf("%d",&A[i][j]);
		}
	}

	for(int i = 0; i < intR; i++) {
		printf("\nEnter Value Number [%d] in Vector X: ",i);
		scanf("%d",&X[i]);
	}
	
	printf("\n Matrix A:\n");
	for(int i = 0; i < intR; i++) {
                for(int j = 0; j < intC; j++){    
                        printf("%d  ",A[i][j]);
                } 
                printf("\n");     
        }

	printf("\n Vector X:\n");
	for(int i = 0; i < intR; i++) {
	 	printf("%d  ",X[i]);
        } 	
			
	MatrixVectorOp(intC,A,X,intR);
    return 0;
}

void MatrixVectorOp(int Col,int Arr1[][Col], int Arr2[], int Row){

int Arr[Row];
	
	for(int i = 0; i< Row; i++) {
		Arr[i] = 0;
	}
	printf("\n Final Result:\n");
	for(int i = 0; i < Row; i++) {
		for(int j = 0; j < Col; j++) {
			Arr[i] += Arr2[i] * Arr1[i][j];
				
			}
		printf("%d  ",Arr[i]);
		}
	printf("\n");	
}		
	
