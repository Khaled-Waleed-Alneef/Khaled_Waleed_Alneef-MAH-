#include <stdio.h>
#include <stdlib.h>

void Push(int *arr,int N,int C);
void Pop(int *arr,int C);
void disp(int *arr,int C);
 
int main(){

char chA;
int counter = 0,N;
int *Arr = (int*) malloc (sizeof(int));
	
	while(1) {
		printf("\nEnter a command (p: push, o: pop, d: display, e: exit): ");
		scanf(" %c",&chA);	
	
		if(chA == 'p'){
		printf("\nEnter an integer to push: ");
		scanf("%d",&N);
		counter++;
		Push(Arr,N,counter);
		}
		
		else if(chA == 'o') {
		Pop(Arr,counter);
		counter--;
		if(counter >= 0)
		printf("\n Popped: %d",Arr[counter]);
		}
		
		else if(chA == 'd')
		disp(Arr,counter);
		
		else if(chA == 'e') 
		break;

		else 
		printf("\nWrong Choice #_#\n");
		
	}
	
  return 0;
}

void Push(int *arr,int N,int C){
	
	arr = realloc(arr,C * sizeof(int));
	arr[C-1] = N;
	
	
}

void Pop(int *arr,int C){
	arr = realloc(arr,sizeof(int));
}

void disp(int *arr,int C){
	printf("\n Stack: ");
	for(int i = 0; i < C; i++) {
		printf("%d ",arr[i]);
	}
}
