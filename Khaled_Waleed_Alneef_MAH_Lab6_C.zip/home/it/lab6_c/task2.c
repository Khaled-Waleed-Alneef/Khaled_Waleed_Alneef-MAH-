#include <stdio.h>
#include <stdlib.h>

void Reverse(char *str1,int N);

int main(){
int N;

	printf("\nEnter Size of String: ");
	scanf("%d",&N);	


char *str = (char*) malloc (N + 1);

	printf("\nEnter String: ");
        scanf(" %s",str);

	Reverse(str,N);
	
  return 0;

}	

void Reverse(char *str1,int N){
	int j = 2;
	char *str2 = (char*) malloc (2);
	
	for(int i = N-1; i >= 0; i--) {
	str2 = realloc(str2,j);
	str2[j-2] = str1[i];
	str2[j-1] = '\0';
	str1 = realloc(str1,i);
	j++;
	}
	printf("String Reversed: %s\n",str2);
}
