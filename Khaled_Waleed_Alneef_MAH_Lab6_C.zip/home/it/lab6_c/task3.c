#include <stdio.h>
#include <stdlib.h>

void Func();

int main(){

	Func();	
  return 0;
}

void Func(){
int N, counter = 2, total = 0;
int *num = (int*) malloc(sizeof(int)); 
char chD;

    printf("\nEnter an Integer: ");
    scanf("%d", &N);
    num[0] = N;

    while (1) {
        printf("\nDo you want to add more samples? (y/n): ");
        scanf(" %c", &chD);

        if (chD == 'y') {
            printf("\nEnter a sample integer value: ");
            scanf("%d", &N);
            num = realloc(num, sizeof(int) * counter); 
            num[counter - 1] = N; 
            counter++;
        } 
	else if(chD == 'n') {
            for (int i = 0; i < counter - 1; i++) {
                total += num[i]; 
            }

            float Avg = (float)total / (counter - 1); 

            printf("\nAverage: %f", Avg);
            printf("\nYou entered the following samples: ");
            for (int i = 0; i < counter - 1; i++) { 
                printf("%d ", num[i]);
            }
	    printf("\nFinal adjusted samples after DC shift:");
	    for (int i = 0; i < counter - 1; i++) {
                num[i] -= Avg;
		printf("%d ", num[i]);
            }

            printf("\n");
            break; 
        }
	else 
	printf("\nWrong choice #_#");

    }
	printf("\n");
	free(num);
}
