#include <stdio.h>
#include <stdlib.h>

void Function(int *X, int *Y, int *Z,int A,int B,int N);

int main(){
int N,A,B;


	printf("\nEnter Size of Vectors (N): ");
	scanf("%d",&N);


int *Xarr = (int*) malloc (N * sizeof(int));
int *Yarr = (int*) malloc (N * sizeof(int));
int *Zarr = (int*) malloc (N * sizeof(int));

	printf("\nEnter Scalars Values (A,B): ");
        scanf("%d%d",&A,&B);

	for(int i = 0; i < N; i++) {
		printf("\nEnter Value %d For Vector X: ",i+1);
		scanf("%d",&Xarr[i]);
	}

	for(int i = 0; i < N; i++) {
                printf("\nEnter Value %d For Vector Y: ",i+1);
                scanf("%d",&Yarr[i]);
        }

	if(Xarr == NULL || Yarr == NULL || Zarr == NULL)
	printf("\nOne of the pointers is pointing to NULL #_#");
	else
	Function(Xarr,Yarr,Zarr,A,B,N);
	free(Xarr);
	free(Yarr);
	free(Zarr);
 return 0;
}


void Function(int *X, int *Y, int *Z,int A,int B,int N){

	printf("\nZ = ");
	for(int i = 0; i < N; i++) {
		Z[i] = A * X[i] + B * Y[i];
		printf("%d ",Z[i]);
	}
	printf("\n");
}
