#include <stdio.h>

int main(){

int intN;
float fInc;

	printf("Enter a positive integer N:");
	scanf("%d",&intN);

	printf("\nNumbers from 20 to 0 in descending order:\n");

	for(int i = intN; i >= 0; i--){
		printf("%d ",i);
	};

	printf("\nNumbers from 1 to 20 following pattern B:\n");
	
        for(int i = 0; i <= intN; i++){
                printf(" %d ",i);
        };

	
	printf("\nEnter an increment value less than 1:");
	scanf(" %f",&fInc);

	for(float i = 0; i <= intN;){
		printf(" %f ",i);
		i = i + fInc;
        };
	printf("\n");


	return 0;
}
