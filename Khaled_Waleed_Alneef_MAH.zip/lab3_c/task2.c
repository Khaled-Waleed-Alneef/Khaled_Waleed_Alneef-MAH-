#include <stdio.h>

int main(){

int intN,intP = 0;

	printf("Enter a Number: ");
	scanf("%d",&intN);

	if(intN <= 0) {
	printf("%d is NOT a Prime Number\n",intN);
	}	
	
	else {

	for(int i = 2; i < intN; i++) {
	
		if(intN % i == 0){
		intP = 1;
		break; 
			}
		} 	
        }

	if(intP == 0)
	printf("%d is Prime Number\n",intN);
	
	else
	printf("%d is NOT a Prime Number\n",intN);

	return 0;
}
