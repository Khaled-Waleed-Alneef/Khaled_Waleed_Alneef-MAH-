#include <stdio.h>

int main(){

int intN, intNA = 0,intNE = 0 , intNI = 0, intNO = 0, intNU = 0, intNOther = 0;
	printf("\nEnter The Number of Characters: ");
	scanf("%d",&intN);
char chN[intN-1];

	for(int i = 0; i < intN; i++) {

		printf("Enter The Character %d: ",i+1);
		scanf(" %c",&chN[i]);	
	
	}

	for(int i = 0; i < intN; i++) {

		switch(chN[i]) {
			case 'a': intNA +=1; break;
			case 'e': intNE +=1; break;
			case 'i': intNI +=1; break;
			case 'o': intNO +=1; break;
			case 'u': intNU +=1; break;
			default: intNOther +=1; break;
		}
	}

	printf("\nFrequency of a: %d",intNA);
	printf("\nFrequency of e: %d",intNE);
	printf("\nFrequency of i: %d",intNI);
	printf("\nFrequency of o: %d",intNO);
	printf("\nFrequency of u: %d",intNU);
	printf("\nFrequency of others: %d\n",intNOther);
	
	return 0;
}			
