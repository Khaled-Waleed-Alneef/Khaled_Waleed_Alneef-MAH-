#include <stdio.h>

int main(){

int intX, intY;
char chDir;
	printf("Enter X: ");
	scanf("%d",&intX);

	printf("Enter Y: ");
	scanf("%d",&intY);
	
	if (intX <= 0 || intX >= 4 || intY <= 0 || intY >= 4) {
        printf("Invalid initial position. Must be X = 0-3, Y = 0-3");
      }
	else {
		
	while(1){
	printf("Enter the direction to move (U for Up, D for Down, L for Left, R for Right): ");
	scanf(" %c", &chDir);
	switch(chDir) {
		
		case'U': intY++; break;
		case'D': intY--; break;
		case'L': intX--; break;
		case'R': intX++; break;
		Default: printf("\nWrong Choice !\n"); break;

		}
	
	printf("\nCurrent Location is: (%d,%d)\n",intX,intY);
	
	if(intX <= 0 || intX >= 4 || intY <= 0 || intY >= 4){
	printf("\nThe player has reached the boundary\n");
	break;
		}
	}
	
     }

return 0;

}
