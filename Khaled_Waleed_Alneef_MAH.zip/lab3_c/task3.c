#include <stdio.h>

int main(){


int i, intMax, intMin, intTotal = 0;
float fMean;
	printf("Enter the number of cities: ");
	scanf("%d",&i);

int intArr[i-1];

	for(int j = 0; j < i; j++) {
		printf("Enter the population of city %d: ",j+1);
		scanf("%d",&intArr[j]);
		intTotal += intArr[j];
	}
	
	fMean = intTotal / i;
	printf("\nMean population: %f",fMean);
	
	intMax = intArr[0];

	for(int j = 1; j < i; j++) {
		if(intArr[j] > intMax)
		intMax = intArr[j];
	}

	printf("\nMax population: %d",intMax);

         intMin = intArr[0];

        for(int j = 1; j < i; j++) {
                if(intArr[j] < intMin)
                intMin = intArr[j];
        }

        printf("\nMin population: %d\n",intMin);
	
	return 0;
}
