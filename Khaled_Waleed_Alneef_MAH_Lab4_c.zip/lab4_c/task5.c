#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){

srand(time(NULL));

int intArr[10][10][3];
float fArr2[10][10];

	for(int i = 0; i < 10; i++) {
		for(int j = 0; j < 10; j++) {
			intArr[i][j][0] = rand() % 256;
			intArr[i][j][1] = rand() % 256;
			intArr[i][j][2] = rand() % 256;
			printf("\n(R = %d, G = %d,B = %d)",intArr[i][j][0],intArr[i][j][1],intArr[i][j][2]);
		}	
	}

	for(int i = 0; i < 10; i++) {
                for(int j = 0; j < 10; j++) {
			fArr2[i][j] = 0.299 * intArr[i][j][0] + 0.587 * intArr[i][j][1] + 0.114 * intArr[i][j][2];
			printf("\n(Grayscale = %f)",fArr2[i][j]);
 
                }
        }
  return 0;
}
