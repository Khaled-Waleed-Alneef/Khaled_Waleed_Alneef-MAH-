#include <stdio.h>

int main(){

int intArr[10], intMax, intMin, intTotal = 0;
float fAvg;

	for(int i = 0; i < 10; i++) {
		printf("Enter Population of City %d: ",i+1);
		scanf("%d",&intArr[i]);
	}

	printf("Print the population in reverse order: ");

	for(int i = 9; i >= 0; i--) {
		printf("\n%d",intArr[i]);
	}
	
	intMax =intArr[0];
	
	for(int i = 0; i < 10; i++) {
		if(intMax < intArr[i])
		intMax = intArr[i];
	}

	intMin =intArr[0];

	for(int i = 0; i < 10; i++) {
                if(intMin > intArr[i])
                intMin = intArr[i];
        }

	for(int i = 0; i < 10; i++) {
		intTotal += intArr[i];
	}

	fAvg = intTotal / 10;

	printf("\n\nMax: %d\n",intMax);
	printf("Min: %d\n",intMin);
	printf("Average: %f\n",fAvg);
  return 0;
}		
