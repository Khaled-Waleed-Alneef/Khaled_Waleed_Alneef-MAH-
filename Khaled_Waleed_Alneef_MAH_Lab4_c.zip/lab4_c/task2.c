#include <stdio.h>

int main(){

int intN, intM = 0, intS;

	printf("Enter The Time: ");
	scanf("%d",&intN);
	
	printf("M:S\n");

	
	for(intM; intM < intN; intM++) {
		for(intS = 0; intS <= 59; intS++) {
			if(intS <= 3 || intS == 59)
			printf("%02d:%02d\n",intM,intS);
			else if(intM == intN-1 && intS <= 1)
			printf("%02d:%02d\n",intM,intS);
			else if(intM == intM-1 && intS == 59)
			printf("%02d:%02d\n",intM,intS);
			else if(intS >= 20 && intS <= 23)
			printf("|\n");
		}
	}
	
  return 0;
}	
