#include <stdio.h>

int main(){

int intN, intI = 0, intJ, intRow = 0;


	printf("Enter Number of Rows: ");
	scanf("%d",&intN);
	
	for(intI; intI <= intN; intI++) {
		for(intJ = 0; intJ <= intRow; intJ++){
			printf("*");
		}
		printf("\n");
		intRow += 1;
	}

   return 0;
}
