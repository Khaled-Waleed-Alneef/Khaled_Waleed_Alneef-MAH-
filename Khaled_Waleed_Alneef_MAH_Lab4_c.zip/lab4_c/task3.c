#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){

srand(time(NULL));
int intTX = rand() % 10, intTY = rand() % 10, intX, intY;

	for(intX = 0; intX <= 9; intX++) {
		for(intY = 0; intY <= 9; intY++) {
			if(intX == intTX && intY == intTY) 
			printf("Hurrah!, I have found the hidden treasure in location (%d,%d)\n",intX,intY);
			
		}
	}
	
  return 0;
} 
